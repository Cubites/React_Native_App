import { getDownloadURL, ref, uploadBytesResumable } from 'firebase/storage';
import React, { useState } from 'react'
import { storage } from './config/firebase'

//firebase 업로드 구현

const App = () => {
  const [progress, setProgress] = useState(0);
  const handleSubmit = (e) => {
     e.preventDefault();
     const file = e.target[0].files[0];
     uploadFiles(file)
  }

  const uploadFiles = (file) => {
     if(!file) return;
     const storageRef = ref(storage, '/files/${file.name}');
     const uploadTask = uploadBytesResumable(storageRef, file);

     uploadTask.on("state_changed", (snapshot) => {
         const prog = Math.round((snapshot.bytesTransferred / snapshot.totalBytes) * 100);
         
         setProgress(prog);
      }, (err) => console.log(err),
         ()=>{
            getDownloadURL(uploadTask.snapshot.ref)
            .then((url)=> console.log('업로드된 파일주소를 받을 때 :' + url))
         });
  }

  return (
    <div>
       UpLoad <br />
       <form onSubmit={handleSubmit}>
          <input type="file" className="input" />
          <button type="submit">업로드</button>

       </form>
       <hr />
       <h3>업로드 {progress} %</h3>  
    </div>
  )
}

export default App